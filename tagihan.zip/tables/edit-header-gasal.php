<thead class="thead-dark text-center">
    <tr>
        <th>Virtual Account</th>
        <th>Nama</th>
        <th>Kelas</th>
        <th>No. Ortu</th>

        <th>Penerimaan</th>
        <th>Juli</th>
        <th>Agustus</th>
        <th>September</th>
        <th>Oktober</th>
        <th>November</th>
        <th>Desember</th>


        <th>Tunggakan</th>
        <th>Juli</th>
        <th>Agustus</th>
        <th>September</th>
        <th>Oktober</th>
        <th>November</th>
        <th>Desember</th>
    </tr>
</thead>
