<tr>
    <td>${trx.virtual_account}</td>
    <td>${trx.user}</td>
    <td>${formatToIDR(trx.trx_amount)}</td>
    <td>${trx.trx_timestamp}</td>
</tr>