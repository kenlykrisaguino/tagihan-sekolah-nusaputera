<tr><td>NIS</td><td>${siswa.nis}</td></tr>
<tr><td>Nama</td><td>${siswa.name}</td></tr>
<tr><td>Virtual Account</td><td>${siswa.virtual_account}</td></tr>
<tr><td>Jenjang</td><td>${siswa.jenjang}</td></tr>
<tr><td>Tahun</td><td>${siswa.tahun_ajaran}</td></tr>
<tr><td>Semester</td><td>${siswa.semester}</td></tr>