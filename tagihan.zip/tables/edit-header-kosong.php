<thead class="thead-dark text-center">
    <tr>
        <th>Virtual Account</th>
        <th>Nama</th>
        <th>Kelas</th>
        <th>No. Ortu</th>
        <th>Penerimaan</th>
        <th>Tunggakan</th>
    </tr>
</thead>