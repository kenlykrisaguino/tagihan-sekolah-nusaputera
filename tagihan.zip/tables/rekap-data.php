<tr>
    <td>${trx.virtual_account}</td>
    <td>${trx.student_name}</td>
    <td>${trx.class}</td>
    <td>${trx.parent_phone}</td>
    <td>${formatToIDR(trx.penerimaan)}</td>
    <td>${formatToIDR(trx.tunggakan)}</td>
</tr>