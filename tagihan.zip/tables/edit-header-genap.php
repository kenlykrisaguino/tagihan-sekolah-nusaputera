<thead class="thead-dark text-center">
    <tr>
        <th>Virtual Account</th>
        <th>Nama</th>
        <th>Kelas</th>
        <th>No. Ortu</th>

        <th>Penerimaan</th>
        <th>Januari</th>
        <th>Februari</th>
        <th>Maret</th>
        <th>April</th>
        <th>Mei</th>
        <th>Juni</th>


        <th>Tunggakan</th>
        <th>Januari</th>
        <th>Februari</th>
        <th>Maret</th>
        <th>April</th>
        <th>Mei</th>
        <th>Juni</th>
    </tr>
</thead>
